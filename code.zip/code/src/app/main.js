export const main = {
  template: require('./main.html')
};
