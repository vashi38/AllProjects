Steps to see the output:

npm install

npm run serve


Thanks
Shivanand
mob no: 8483931563
shivanandsonnad@gmail.com